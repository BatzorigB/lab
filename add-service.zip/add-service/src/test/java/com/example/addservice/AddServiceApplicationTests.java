package com.example.addservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AddServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
