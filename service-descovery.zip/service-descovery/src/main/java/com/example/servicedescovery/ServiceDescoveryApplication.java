package com.example.servicedescovery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceDescoveryApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceDescoveryApplication.class, args);
	}

}
