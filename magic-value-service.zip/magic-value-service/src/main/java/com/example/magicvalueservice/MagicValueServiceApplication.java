package com.example.magicvalueservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MagicValueServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MagicValueServiceApplication.class, args);
	}

}
