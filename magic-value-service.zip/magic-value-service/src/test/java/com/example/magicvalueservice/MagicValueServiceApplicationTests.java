package com.example.magicvalueservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MagicValueServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
